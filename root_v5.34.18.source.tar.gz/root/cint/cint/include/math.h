#ifndef G__MATH_H
#define G__MATH_H
#define 	EDOM (33)
#define 	ERANGE (34)
#define 	HUGE_VAL (1.79769e+308)
#pragma include_noerr <stdfunc.dll>
#endif
