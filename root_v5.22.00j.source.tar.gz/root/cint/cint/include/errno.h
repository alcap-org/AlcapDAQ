#ifndef G__ERRNO_H
#define G__ERRNO_H
/* extern int errno; */
#endif
