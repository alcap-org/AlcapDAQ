/* -*- C++ -*- */
/*************************************************************************
 * Copyright(c) 1995~2005  Masaharu Goto (cint@pcroot.cern.ch)
 *
 * For the licensing terms see the file COPYING
 *
 ************************************************************************/
/**************************************************************************
* readfile.h
*
**************************************************************************/
#ifndef G__REGEXP_H
#define G__REGEXP_H


#ifndef G__REGEXPSL

#ifdef G__SHAREDLIB
#pragma include <RegE.dll>
#else
#include <RegE.C>
#endif

#endif

