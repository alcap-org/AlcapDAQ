/* -*- C++ -*- */
/*************************************************************************
 * Copyright(c) 1995~2005  Masaharu Goto (cint@pcroot.cern.ch)
 *
 * For the licensing terms see the file COPYING
 *
 ************************************************************************/
/****************************************************************
* fcntl.h
*****************************************************************/
#ifndef G__FCNTL_H
#define G__FCNTL_H

#pragma include_noerr <systypes.h>
#ifndef G__SYSTYPES_H
typedef unsigned short mode_t;
#endif

#endif
