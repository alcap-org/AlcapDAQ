/* -*- C++ -*- */
/*************************************************************************
 * Copyright(c) 1995~2005  Masaharu Goto (cint@pcroot.cern.ch)
 *
 * For the licensing terms see the file COPYING
 *
 ************************************************************************/
#ifdef __MAKECINT__
#include <X11/Xlib.h>
#include <X11/Xutil.h>
/* Following pragmas delete symbols in abobe headers only.
 * Symbols in following headers will not be affected. */
#pragma link off all functions;
#pragma link off all typedefs;
#pragma link off all classes;
#endif

#include <GL/gl.h>
#include <GL/glu.h>
//#include <GL/glut.h>
#include <GL/glx.h>
//#include <GL/xmesa.h>
