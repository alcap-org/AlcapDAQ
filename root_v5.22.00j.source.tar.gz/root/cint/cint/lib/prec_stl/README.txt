lib/prec_stl

 This directory contains STL dummy header files for precompiling 
instantiated STL container classes.

