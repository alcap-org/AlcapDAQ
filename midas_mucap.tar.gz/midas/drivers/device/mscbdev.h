/********************************************************************\

  Name:         mscbdev.h
  Created by:   Stefan Ritt

  Contents:     Device driver function declarations for MSCB device

  $Log: mscbdev.h,v $
  Revision 1.1.1.1  2005/06/20 23:37:09  mucap
  Importing release 1.9.5 of the MIDAS source code as distributed by PSI.
  (Next, I'll commit our local customizations.)

  Revision 1.1  2003/05/12 10:30:16  midas
  Initial revision


\********************************************************************/

INT mscbdev(INT cmd, ...);
