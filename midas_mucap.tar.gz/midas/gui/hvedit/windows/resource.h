//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HVEDIT.RC
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HVEDIT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDD_CONFIG                      130
#define IDD_NAMES                       131
#define IDB_BITMAP1                     132
#define IDD_HOST                        133
#define IDD_HOSTDLG                     134
#define IDD_PASSDLG                     135
#define IDD_PRINT                       136
#define IDC_LIST_GROUP                  1002
#define IDC_LIST_CHANNELS               1003
#define IDC_EXPERIMENT                  1004
#define IDC_EDIT                        1004
#define IDC_SET                         1007
#define IDC_P1                          1008
#define IDC_P10                         1009
#define IDC_P100                        1010
#define IDC_M1                          1011
#define IDC_M10                         1012
#define IDC_M100                        1013
#define IDC_ZERO                        1014
#define IDC_RESTORE                     1015
#define IDC_SAVE                        1018
#define IDC_LOAD                        1019
#define IDC_PRINT                       1020
#define IDC_SELALL                      1021
#define IDC_HLP                         1022
#define IDC_CONFIG                      1023
#define IDC_COMBO1                      1024
#define IDC_HOST                        1026
#define IDC_ROOT                        1027
#define IDC_EDIT_NAMES                  1028
#define IDC_LIST                        1032
#define IDC_EDIT1                       1033
#define IDC_EDIT2                       1034
#define IDC_CHANGE                      1037
#define IDC_ALL_OFF                     1039
#define IDC_MESSAGE                     1040
#define IDC_SEL                         1041
#define IDC_RADIO2                      1042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
