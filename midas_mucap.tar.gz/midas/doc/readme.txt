Welcome to the MIDAS data acquisition system. This system
can be used at small and medium size experiments in nuclear
and particle physics. For an overview read OVERVIEW, 
for installation instructions read INSTALL. If you want to
compile a sample experiment, follow the instructions under
examples/experiment/readme.txt.

The primary web side is located at http://midas.psi.ch,
where also a online version of the manual can be found.

Please send questions and comments to

/=========================================================\
| Dr. Stefan Ritt                                         |
| Paul Scherrer Institute    Phone: +41 56 310 3728       |
| WPGA/3                     FAX  : +41 56 310 3171       |
| CH-5232 Villigen PSI       mailto:Stefan.Ritt@psi.ch    |
| Switzerland                http://pibeta.psi.ch/~stefan |
\=========================================================/
